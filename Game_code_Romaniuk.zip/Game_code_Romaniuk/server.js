//server.js

const express = require('express');
const app = express();
const port = 3000;
const pl = require('tau-prolog');
require("tau-prolog/modules/lists")(pl);

app.use(express.static('public'));
app.use(express.json());

app.post('/solve', (req, res) => {
    const equation = req.body.equation;
    const matchesToAdd = req.body.matchesToAdd;
    const prologInput = convertEquationToPrologList(equation);
    const prologQuery = `game([${prologInput}], ${matchesToAdd}, Res, Gen).\n`;
    let session = pl.create();
    let program = `
:- use_module(library(lists)).
//код на Пролог
`;
    session.consult(program, {
        success: function() {
            let query = `game([${prologInput}], ${matchesToAdd}, Res, Gen).\n`;
            session.query(query, {
                success: function(goal) {
                    session.answer({
                        success: function(answer) {
                            let formattedSolution = parsePrologOutput(session.format_answer(answer));
                            res.json(formattedSolution);
                        },
                        fail: function() {
                            res.json({solution: "No solution found."});
                        },
                        error: function(err) {
                            console.error(err);
                            res.status(500).json({error: "Prolog execution error."});
                        }
                    });
                },
                error: function(err) {
                    console.error(err);
                    res.status(500).json({error: "Query error."});
                }
            });
        },
        error: function(err) {
            console.error(err);
            res.status(500).json({error: "Consult error."});
        }
    });
});
function convertEquationToPrologList(equation) {
    return equation.split('').map(c => isNaN(parseInt(c)) ? `'${c}'` : c).join(', ');
}
function parsePrologOutput(stdout) {
    const lines = stdout.split('\n').filter(line => line.trim() !== '');
    const resPattern = /Res = (.+).$/;
    const genPattern = /Gen = (.+).$/;
    let resMatch = lines.find(line => resPattern.test(line));
    let genMatch = lines.find(line => genPattern.test(line));

    let resOutput = resMatch ? formatPrologList(resMatch.match(resPattern)[1].split(" Gen = ")[0]) : 'Рішення не знайдено';
    let genOutput = genMatch ? formatPrologList(genMatch.match(genPattern)[1]) : 'Додаткові рішення не знайдені';

    return { solution: resOutput, additionalSolution: genOutput };
}
function formatPrologList(prologList) {
    let formattedString = prologList
        .replace(/\[\[/g, '')
        .replace(/\]\]/g, '')
        .replace(/\],\s*\[/g, '; ')
        .replace(/\[|\]/g, '')
        .replace(/,/g, '');

    return formattedString;
}
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});





